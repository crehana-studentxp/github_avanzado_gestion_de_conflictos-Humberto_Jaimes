PREFIX=github_gestion_conflictos-humberto_jaimes_
CLASS=proyecto_final_2

git clone $CLASS.bundle

gh repo delete $PREFIX$CLASS --confirm

REPONAME=$(gh repo create $PREFIX$CLASS --private)

REPOURL=$(gh repo view $REPONAME --json url -q ".url") 

cd $CLASS

git checkout -b change_header_logo remotes/origin/change_header_logo
git checkout -b develop remotes/origin/develop
git checkout -b fix_html_encoding remotes/origin/fix_html_encoding
git checkout -b fixes_before_release remotes/origin/fixes_before_release
git checkout -b fixes_header_footer remotes/origin/fixes_header_footer
git checkout -b refactor_header_and_footer remotes/origin/refactor_header_and_footer
git checkout -b remove_unnecesary_pages remotes/origin/remove_unnecesary_pages
git checkout main 

git remote set-url origin $REPOURL

git checkout main 
git push
git checkout change_header_logo
git push
git checkout develop
git push
git checkout fix_html_encoding
git push
git checkout fixes_before_release
git push
git checkout fixes_header_footer
git push
git checkout refactor_header_and_footer
git push
git checkout remove_unnecesary_pages
git push

cd ..