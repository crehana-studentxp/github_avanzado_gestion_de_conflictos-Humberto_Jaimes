PREFIX=github_gestion_conflictos-humberto_jaim_
CLASS=proyecto_final_1

git clone $CLASS.bundle

gh repo delete $PREFIX$CLASS --confirm

REPONAME=$(gh repo create $PREFIX$CLASS --private)

REPOURL=$(gh repo view $REPONAME --json url -q ".url") 

cd $CLASS

git checkout main 

git remote set-url origin $REPOURL

git checkout main 
git push


cd ..